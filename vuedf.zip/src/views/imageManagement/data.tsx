import { categoryOptions } from '/@/utils/options';
import { FormSchema } from '/@/components/Form/index';
import { useI18n } from '/@/hooks/web/useI18n';
import { h } from 'vue';

const { t } = useI18n();

//tabs
export const tabOptions = [
  { value: 1, label: t('component.gamesManagement.country') },
  { value: 2, label: t('component.imageManagement.team') },
];

//schema
const schema: { country: FormSchema[]; team: FormSchema[] } = {
  //國家
  country: [
    {
      field: 'name',
      component: 'Select',
      label: t('component.imageManagement.countryName'),
      componentProps: {
        placeholder: t('common.chooseText'),
        options: [
          { label: 'Austrian Amateur Cup', value: 1 },
          { label: 'Giải K3 Hàn Quốc-Vòng 29', value: 2 },
        ],
      },
      colProps: { span: 4 },
    },
  ],
  //隊伍
  team: [
    {
      field: 'category',
      component: 'Select',
      label: t('common.type'),
      componentProps: {
        placeholder: t('common.chooseText'),
        options: categoryOptions,
      },
      colProps: { span: 4 },
    },
    {
      field: 'name',
      component: 'Select',
      label: t('component.imageManagement.teamName'),
      componentProps: {
        placeholder: t('common.chooseText'),
        options: [],
      },
      colProps: { span: 4 },
    },
  ],
};
export const getSchema = (activeKey: number) => {
  if (activeKey == 1) {
    return schema.country; //國家
  } else {
    return schema.team; //隊伍
  }
};

//columns
const customSlot = () => {
  return {
    default: ({ row, column }) => {
      return h('div', { class: 'grid justify-items-center' }, [
        h('img', { src: row[column.field], class: 'h-5' }),
      ]);
    },
  };
};
const columns: { country: any; team: any } = {
  //國家
  country: [
    { type: 'seq', width: 80 },
    { title: t('component.upload.image'), field: 'img', slots: customSlot() },
    { title: t('component.imageManagement.countryName'), field: 'name' },
    { title: t('common.memo'), field: 'memo' },
    { title: t('common.action'), field: 'action', width: 200, slots: { default: 'bodyCell' } },
  ],
  //隊伍
  team: [
    { type: 'seq', width: 80 },
    { title: t('common.type'), field: 'category' },
    { title: t('component.upload.image'), field: 'img', slots: customSlot() },
    { title: t('component.imageManagement.teamName'), field: 'name' },
    { title: t('common.memo'), field: 'memo' },
    { title: t('common.action'), field: 'action', width: 200, slots: { default: 'bodyCell' } },
  ],
};
export const getColumns = (activeKey: number) => {
  if (activeKey == 1) {
    return columns.country; //國家
  } else {
    return columns.team; //隊伍
  }
};
