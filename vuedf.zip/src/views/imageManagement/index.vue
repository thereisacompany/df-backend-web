<template>
  <PageWrapper :fixSmallWidth="false" class="custom-pageTitle">
    <PageHeader>
      <template #title>
        <div class="flex justify-between">
          <div>{{ t('routes.menu.ImageManagement') }}</div>
          <div>
            <a-button type="primary" class="w-36" @click="openModal({ id: 0 })">
              <Icon class="mr-2" icon="ion:plus-circled" :size="14" />
              {{
                activeKey == 1
                  ? t('component.imageManagement.addCountry')
                  : t('component.imageManagement.addTeam')
              }}
            </a-button>
          </div>
        </div>
      </template>
    </PageHeader>

    <!-- Tabs -->
    <Tabs class="custom-tab" v-model:activeKey="activeKey" @tab-click="changeTab">
      <TabPane v-for="v in tabOptions" :key="v.value" :tab="v.label" />
    </Tabs>

    <!-- TheFilter -->
    <TheFilter :advanced="false" @click-reset="handleReset" @click-submit="handleSubmit">
      <template #BasicForm>
        <BasicForm
          ref="formSearchRef"
          layout="vertical"
          :schemas="schemas"
          :labelWidth="186"
          :baseColProps="{ span: 24 }"
          :baseRowStyle="{ alignItems: 'end' }"
          :wrapperCol="{ span: 21 }"
          :showActionButtonGroup="false"
          @keypress.enter="handleEnterPress"
        />
      </template>
    </TheFilter>

    <!-- table -->
    <vxe-grid
      v-if="tableData.dataSource"
      stripe
      show-overflow
      border="inner"
      align="center"
      class="ceos-basic-table"
      :max-height="380"
      :row-config="{ height: 57 }"
      :columns="tableData.columns"
      :data="tableData.dataSource"
    >
      <template #bodyCell="{ column, row }">
        <template v-if="column.field === 'action'">
          <TableAction
            class="custom-acton-buttons"
            outside
            :actions="[
              {
                icon: 'clarity:note-edit-line',
                tooltip: t('common.edit'),
                onClick: () => handleEdit(row),
              },
              {
                icon: 'material-symbols:delete-outline-rounded',
                tooltip: t('common.delete'),
                onClick: () => {
                  handleDelete(row);
                },
              },
            ]"
          />
        </template>
      </template>
    </vxe-grid>

    <!-- 詳細資料 -->
    <Detail ref="detailRef" :activeKey="activeKey" @reload="loadData" />
  </PageWrapper>
</template>

<script lang="ts">
  import { defineComponent, onMounted, reactive, computed, ref } from 'vue';
  import { TableAction } from '/@/components/Table';
  import { PageHeader, Tabs, TabPane } from 'ant-design-vue';
  import { BasicForm } from '/@/components/Form/index';
  import { TheFilter } from '/@/components/TheFilter';
  import { showConfirm } from '/@/utils/globalTips';
  import { PageWrapper } from '/@/components/Page';
  import { useI18n } from '/@/hooks/web/useI18n';
  import { Icon } from '/@/components/Icon';

  //components
  import Detail from './components/Detail/index.vue';
  // import { CustomVxeTable } from '/@/components/CustomVxeTable';

  //data
  import { categoryOptions } from '/@/utils/options';
  import { getColumns, getSchema, tabOptions } from './data';
  import XEUtils from 'xe-utils';

  export default defineComponent({
    components: {
      Icon,
      PageWrapper,
      PageHeader,
      BasicForm,
      TableAction,
      Tabs,
      TabPane,
      TheFilter,
      Detail,
    },
    setup() {
      const { t } = useI18n();
      /*=========values=========*/
      //Tabs
      const activeKey = ref<number>(1);

      //TheFilter
      const formSearchRef = ref<any>(null);
      const schemas = computed(() => getSchema(activeKey.value));
      const searchData = reactive({ title: null, status: null, type: 1 });

      //table
      const tableData = reactive({
        columns: computed(() => getColumns(activeKey.value)),
        dataSource: [],
      });

      //詳細資料
      const detailRef = ref<any>(null);
      /*=========function=========*/
      //Tabs
      const changeTab = (value) => {
        activeKey.value = value;
        loadData();
      };

      //TheFilter
      function handleReset() {
        formSearchRef.value.resetFields();
      }
      function handleSubmit() {
        const values = formSearchRef.value.getFieldsValue();
        searchData.title = values.title ? values.title : '';
        searchData.status = values.status ? values.status : '';
        searchData.type = values.type ? values.type : '';
        console.log(searchData);
      }
      function handleEnterPress(e: KeyboardEvent) {
        if (e.key === 'Enter' && e.target && e.target instanceof HTMLElement) {
          const target: HTMLElement = e.target as HTMLElement;
          if (target && target.tagName) {
            handleSubmit();
          }
        }
      }

      //table
      async function loadData() {
        let list: any = [];
        for (let i = 0; i < 1000; i++) {
          const model = {
            id: i,
            img: 'https://img1.aiscore.com/country/aut.png!w30',
            name: 'Austrian Amateur Cup',
            category: categoryOptions[XEUtils.random(0, 2)].label,
            memo: '備註' + i,
          };
          list.push(model);
        }
        tableData.dataSource = list;
      }
      function handleEdit(record) {
        openModal(record);
      }
      function handleDelete(record) {
        showConfirm({
          iconType: 'warning',
          title: 'Tip',
          content: t('common.confirmDelete'),
          onOk() {
            console.log(record);
            //todo: 串接刪除Api並重新撈取資料
          },
          onCancel() {},
        });
      }

      //common
      const openModal = (row) => {
        detailRef.value.handleOpen(row);
      };

      onMounted(() => {
        loadData();
      });
      /*=========data=========*/
      return {
        t,

        //Tabs
        tabOptions,
        activeKey,
        changeTab,

        //TheFilter
        formSearchRef,
        schemas,
        handleReset,
        handleSubmit,
        handleEnterPress,

        //table
        tableData,
        loadData,
        handleEdit,
        handleDelete,

        //詳細資料
        detailRef,
        openModal,
      };
    },
  });
</script>
<style lang="less" scoped></style>
