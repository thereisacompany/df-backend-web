<template>
  <div>
    <BasicTable
      @register="registerTable"
      @edit-change="handleEditChange"
      class="custom-form-table"
      :bordered="true"
    >
      <template #bodyCell="{ column, record }">
        <template v-if="column.key === 'button'">
          <a-button class="custom-btn-blue custom-size-small" @click="publishBtn(record)">
            發布
          </a-button>
        </template>
        <template v-if="column.key === 'action'">
          <TableAction :actions="createActions(record, column)" />
        </template>
      </template>
    </BasicTable>
    <a-button
      v-if="false"
      block
      class="mt-5 custom-btn-dashed-primary"
      type="dashed"
      @click="handleAdd"
    >
      新增主題
    </a-button>
  </div>
</template>
<script lang="ts">
  import { defineComponent, onMounted, ref, computed } from 'vue';
  import {
    BasicTable,
    useTable,
    TableAction,
    BasicColumn,
    ActionItem,
    EditRecordRow,
  } from '/@/components/Table';

  import { useMQTTStore } from '/@/store/modules/page/MQTT';
  import { doPublish } from '/@/utils/MQTT';
  const columns: BasicColumn[] = [
    {
      title: '主題Topic',
      dataIndex: 'topic',
      editRow: true,
    },
    {
      title: '品質QoS',
      dataIndex: 'qos',
      editRow: true,
      helpMessage: ['0:最多傳送一次', '1:至少傳送一次', '2:確實傳送一次'],
      width: 100,
    },
    {
      title: '備註',
      dataIndex: 'memo',
      editRow: true,
    },
    {
      title: '訊息payload',
      dataIndex: 'payload',
      editRow: true,
    },
    {
      title: '發布',
      dataIndex: 'button',
      align: 'center',
      width: 100,
    },
  ];

  export default defineComponent({
    components: { BasicTable, TableAction },
    setup() {
      //---*變數

      const MQTTStore = useMQTTStore();
      const topicList: any = ref([]);
      //---*table相關
      const [registerTable, { getDataSource }] = useTable({
        columns: columns,
        showIndexColumn: true,
        dataSource: topicList,
        canResize: false,
        actionColumn: {
          width: 160,
          title: '操作',
          dataIndex: 'action',
          ifShow: false,
        },
        pagination: false,
      });

      function handleEdit(record: EditRecordRow) {
        record.onEdit?.(true);
      }

      function handleCancel(record: EditRecordRow) {
        record.onEdit?.(false);
        if (record.isNew) {
          const data = getDataSource();
          const index = data.findIndex((item) => item.key === record.key);
          data.splice(index, 1);
        }
      }

      function handleSave(record: EditRecordRow) {
        record.onEdit?.(false, true);
      }

      function handleEditChange(data: Recordable) {
        console.log(data);
      }
      //---*新增主題
      function handleAdd() {
        const data = getDataSource();
        const addRow: EditRecordRow = {
          name: '',
          no: '',
          dept: '',
          editable: true,
          isNew: true,
          key: `${Date.now()}`,
        };
        data.push(addRow);
      }

      function createActions(record: EditRecordRow, column: BasicColumn): ActionItem[] {
        if (!record.editable) {
          return [
            {
              label: '编辑',
              onClick: handleEdit.bind(null, record),
            },
            {
              label: '删除',
            },
          ];
        }
        return [
          {
            label: '保存',
            onClick: handleSave.bind(null, record, column),
          },
          {
            label: '取消',
            popConfirm: {
              title: '是否取消编辑',
              confirm: handleCancel.bind(null, record, column),
            },
          },
        ];
      }
      //---*發布按鈕
      const publishBtn = (record) => {
        console.log('發布', record);

        doPublish(record);
      };
      //---*設定初始資料
      const setData = () => {
        topicList.value = computed(() => MQTTStore.getSubscription);
      };

      onMounted(async () => {
        setData();
      });
      return {
        registerTable,
        handleEdit,
        createActions,
        handleAdd,
        getDataSource,
        handleEditChange,
        //MQTT
        publishBtn,
      };
    },
  });
</script>
