<template>
  <PageWrapper title="MQTT推播">
    <CollapseContainer title="共用主題" class="mb-5">
      <TableContent ref="tableRef" />
    </CollapseContainer>
  </PageWrapper>
</template>
<script lang="ts">
  import { defineComponent, onMounted } from 'vue';

  import { CollapseContainer } from '/@/components/Container/index';
  import { Input } from 'ant-design-vue';
  import { PageWrapper } from '/@/components/Page';

  import { doPublish } from '/@/utils/MQTT';
  import TableContent from './Table-content.vue';
  export default defineComponent({
    components: {
      CollapseContainer,
      PageWrapper,
      [Input.name]: Input,

      TableContent,
    },
    setup() {
      onMounted(async () => {});

      return { doPublish };
    },
  });
</script>
