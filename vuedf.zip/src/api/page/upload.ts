import { http4100, httpIT10010, httpCommonserver } from '/@/utils/http/axios';

enum Api {
  Classification = '/classification',
  Status = '/status',
  Assets = '/assets',
  Record = '/record',
  Upload = '/assets/upload',
  OrganizationUnits = '/OrganizationUnits',
  urlTransfer = '/url-transfer',
  Files = '/files',
  File = '/file',
}

export function uploadFileApi(id: string | number, data) {
  return httpIT10010.uploadFile(
    {
      url: `https://spring-dev.ceos.center/assetmanagement/${Api.Upload}/${id}/images`,
    },
    data,
  );
}

export function deleteFileApi(id: string | number, imageName: string) {
  return httpIT10010.delete(
    {
      url: Api.Assets + `/delete/${id}/image?name=${imageName}`,
    },
    { errorMessageMode: 'none', isTransformResponse: false },
  );
}

//---*上傳資產圖片連結(由服務將其轉存為檔案)
export function addFileUrl(id: string | number, urls: [] | any) {
  const urlsAry: any = [];
  if (urls.length != 0) {
    for (let j = 0; j < urls.length; ++j) {
      const item = `urls=${urls[j].url}`;
      urlsAry.push(item);
    }
  }

  let urlsString = '';
  urlsString = urlsAry.join('&');

  return httpIT10010.post(
    {
      url: Api.Upload + `/${id}/copyImages?${urlsString}`,
    },
    { errorMessageMode: 'none', isTransformResponse: false },
  );
}

/* Upload
================================================== */
//---* 上傳
export function uploadDocFile(func: string, data) {
  return http4100.uploadFile(
    {
      // url: `http://api.lsgheaven.com:10010/upload/files?function=${func}`,
      url: `https://spring-dev.ceos.center/commonserver/upload/files?function=${func}`,
    },
    data,
  );
}

//---* 刪除
export function deleteDocFile(func: string, file) {
  // console.log('file', file);
  const fileName = file.url.split(`${func}/`).pop();
  return httpCommonserver.delete(
    {
      url: Api.File + `?function=${func}&name=${fileName}`,
    },
    { errorMessageMode: 'none', isTransformResponse: false },
  );
}

//---* 刪除插入的圖片
export function deleteInsertImg(func: string, fileName) {
  return httpCommonserver.delete(
    {
      url: Api.File + `?function=${func}&name=${fileName}`,
    },
    { errorMessageMode: 'none', isTransformResponse: false },
  );
}

//---* 取得檔案路徑
export function getUploadFilesUUID(UUIDs: [] | string) {
  let uuidsString = '';
  Array.isArray(UUIDs) ? (uuidsString = UUIDs.join('&')) : (uuidsString = UUIDs);
  return httpCommonserver.get(
    {
      url: Api.Files + `?${uuidsString}`,
    },
    { errorMessageMode: 'none', isTransformResponse: false },
  );
}
