export { default as CountdownTime } from './src/index.vue';
