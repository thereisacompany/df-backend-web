export { default as LargeDataTable } from './src/largeDataTable.vue';
