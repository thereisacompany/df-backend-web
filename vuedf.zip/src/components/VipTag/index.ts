export { default as VipTag } from './src/index.vue';
