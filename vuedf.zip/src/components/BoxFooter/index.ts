export { default as BoxFooter } from './src/Box-Footer.vue';
