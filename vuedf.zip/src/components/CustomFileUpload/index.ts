export { default as CustomFileUpload } from './src/index.vue';
