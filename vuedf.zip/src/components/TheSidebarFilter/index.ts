export { default as TheSidebarFilter } from './src/TheSidebarFilter.vue';
