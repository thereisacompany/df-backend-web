export { default as TheFilter } from './src/TheFilter.vue';
